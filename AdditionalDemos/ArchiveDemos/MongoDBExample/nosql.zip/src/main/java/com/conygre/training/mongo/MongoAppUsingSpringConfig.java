package com.conygre.training.mongo;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;

/**
 * Created by nicktodd on 24/06/15.
 */
public class MongoAppUsingSpringConfig {


    private static final Log log = LogFactory.getLog(MongoAppUsingSpringConfig.class);

    public static void main(String[] args) {

        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        MongoOperations mongoOps = context.getBean("mongoTemplate", MongoTemplate.class);

        Person p = new Person("Joe", 34);

        // Insert is used to initially store the object into the database.
        mongoOps.insert(p);
        log.info("Insert: " + p);


    }
}
